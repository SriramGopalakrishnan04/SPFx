declare interface IInjectCssApplicationCustomizerStrings {
  Title: string;
}

declare module 'InjectCssApplicationCustomizerStrings' {
  const strings: IInjectCssApplicationCustomizerStrings;
  export = strings;
}
