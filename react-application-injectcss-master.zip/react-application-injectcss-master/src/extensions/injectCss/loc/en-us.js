define([], function() {
  return {
    "Title": "InjectCssApplicationCustomizer"
  }
});