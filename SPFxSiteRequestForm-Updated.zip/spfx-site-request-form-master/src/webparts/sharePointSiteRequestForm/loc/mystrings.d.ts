declare interface ISharePointSiteRequestFormWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SharePointSiteRequestFormWebPartStrings' {
  const strings: ISharePointSiteRequestFormWebPartStrings;
  export = strings;
}
