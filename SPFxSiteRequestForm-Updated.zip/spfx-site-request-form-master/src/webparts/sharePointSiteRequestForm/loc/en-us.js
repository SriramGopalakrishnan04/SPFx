define([], function() {
  return {
    "PropertyPaneDescription": "Configuration",
    "BasicGroupName": "Configuration",
    "DescriptionFieldLabel": "List Name"
  }
});